# Glyph Palette v0.5.2

Hey hey, thanks for being part of the Glyph Palette Alpha!

It’s very basic for now, but with your help it will continually improve.

Contained within this folder is the plugin. Simply double click and it should automatically install to Sketch.

If all is well further updates should happen automatically. Or at least prompted.

Reach out if you have any problems.

[https://x.com/prmack](https://x.com/prmack)
[support@workingon.studio](mailto:support@workingon.studio)
